#include "mpi.h"
#include <stdio.h>
int main(int argc,char **argv)
{
MPI_Init(&argc,&argv);
printf("hello parallel world!\n");
MPI_Finalize();
}
