#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

int main(int argc,char **argv)
{    
    int i, numprocs,namelen,myid;
    char processor_name[MPI_MAX_PROCESSOR_NAME];
    int buf[5];
    int flag=0;
    MPI_Status   status;
    MPI_Request  r;
    MPI_Init( &argc, &argv );
    MPI_Comm_rank( MPI_COMM_WORLD, &myid );
    MPI_Comm_size(MPI_COMM_WORLD,&numprocs);
    MPI_Get_processor_name(processor_name,&namelen);
    if (myid == 0) 
    {
        for(i=0;i<5;i++)
        {
           buf[i]=i;
        }
	MPI_Isend(&buf, 5, MPI_INT, 1, 99, MPI_COMM_WORLD, &r);
    }
    else 
    {
        MPI_Irecv(&buf, 5, MPI_INT, 0, 99, MPI_COMM_WORLD, &r);
        MPI_Test(&r,&flag,&status);
        printf("Before MPI_Wait flag=%d. The buf is can't be used!\n",flag);
        for(i=0;i<5;i++)
        {
             printf("buf[%d]=\t%d \n",i,buf[i]);
        }
        MPI_Wait(&r,&status);
        MPI_Test(&r,&flag,&status);       
        printf("After MPI_Wait flag=%d. The buf is can be used!\n",flag);
        for(i=0;i<5;i++)
        {
             printf("buf[%d]=\t%d \n",i,buf[i]);

        }
    }	
    MPI_Finalize( );
    return 0;
}  

